
PRODIGY_WD_01 - Interactive Navigation Menu

This is Task 1 of my Web Development Internship at Prodigy Infotech.

Task Goal:
Build a fixed navigation menu that:
- Changes background color on scroll
- Highlights menu items on hover
- Is clean, responsive, and user-friendly

Technologies:
HTML, CSS, JavaScript
